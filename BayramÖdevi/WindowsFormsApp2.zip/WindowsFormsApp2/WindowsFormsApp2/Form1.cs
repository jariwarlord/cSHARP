﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader dr;

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                //karakteri göster.
                textBox2.PasswordChar = '\0';
            }
            //değilse karakterlerin yerine * koy.
            else
            {
                textBox2.PasswordChar = '*'; // "*" yerine ne eklerseniz şifreyi gizlerken ne yazmışsanız o şekilde gizler .
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string query = "SELECT * FROM giris WHERE kullaniciAdi=@user AND kullaniciSifresi=@pass";
            con = new SqlConnection("Data Source=LAPTOP-54KT81B2;Initial Catalog=giris;Integrated Security=True");
            cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@user", textBox1.Text);
            cmd.Parameters.AddWithValue("@pass", textBox2.Text);
            con.Open();
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Form2 form2 = new Form2();
                form2.Show();

            }
            else
            {
                MessageBox.Show("Giris basarisiz! Bilgileri kontrol ediniz.");
            }
            con.Close();
        }


    }
}
